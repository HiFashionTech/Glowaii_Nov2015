// NeoWindow
#include "NeoStrip.h"
#include "NeoWindow.h"

//////
// used to invoke the member function pointer...
//#define CALL_MEMBER_FN(object,ptrToMember)  ((object).*(ptrToMember))

// Class Variable definitions:

unsigned long NeoWindow::currTime = 0; // current Millis
int NeoWindow::s_nIDGenerator = 1;

/////////////////
// Constructor
NeoWindow::NeoWindow(NeoStrip *strip, int startPixel, int len)
{
  myId = s_nIDGenerator++;
  myStrip = strip;
  myStartPixel = startPixel;
  myPixelCount = len;
  myEndPixel = myStartPixel + myPixelCount-1;
  efxDone = false;

  lastTime = 0;
//  diffTime = 0;

//  currentEffect = -1; // id of current effect
  effectDelay = 0; // delay between updates of current effect
  curUpdateFunc = NULL;
}

void NeoWindow::printId(void)
{
  Serial.print("NeoWindow ");Serial.println(myId);
}

void NeoWindow::printData(void)
{
  printId();
  Serial.print("   myStartPixel: ");Serial.println(myStartPixel);
  Serial.print("   myPixelCount: ");Serial.println(myPixelCount);
  Serial.print("   myEndPixel: ");Serial.println(myEndPixel);
  Serial.print("   myStartPixel: ");Serial.println(myStartPixel);
}

void NeoWindow::updateWindow(void)
{
  if (!curUpdateFunc) {
    printId(); Serial.println("    No updateFunc");
    return; // no effect defined. quick return
  }
  
   // determine if the current Effect time has passed

   if (NeoWindow::currTime - lastTime < effectDelay) {
//    printId(); Serial.println("    Not yet time");
    return;
   }
   lastTime = NeoWindow::currTime;
   
   // invoke current effect function update
   (this->*curUpdateFunc)();

   myStrip->setStripChanged(); // mark the strip changed
}

void NeoWindow::fillColor(uint32_t color)
{

  for (int i=myStartPixel; i <= myEndPixel; i++)
       myStrip->setPixelColor(i, color); //set rest of window to black
    
  myStrip->setStripChanged(); // mark the strip changed

}

void NeoWindow::fillBlack()
{
    fillColor(0);
}
////////////////////////////////
// Effects here

void NeoWindow::setHoldEfx(int delayTime)
{
  printId(); Serial.println("    set to use hold effect");
  efxDone = false;
  effectDelay = delayTime;
  curUpdateFunc = &NeoWindow::holdUpdateEfx;
}

void NeoWindow::holdUpdateEfx(void) 
{
  // once we are called the hold time has passed so mark us as done
  efxDone = true;  
}

///////////////
void NeoWindow::setCircleEfx(uint32_t color, uint32_t delayTime)
{
  printId(); Serial.println("    set to use circle effect");
  efxDone = false;
  effectDelay = delayTime;
  curUpdateFunc = &NeoWindow::circleUpdateEfx;
  
  // starting a Circle Effect using color and time
  circle_color = color;
  circle_cursor = myStartPixel;

  // setup the initial frame
  myStrip->setPixelColor(circle_cursor, circle_color);
  for (int i=circle_cursor+1; i< myEndPixel; i++)
    myStrip->setPixelColor(i, 0); //set rest of window to black
    
  myStrip->setStripChanged(); // mark the strip changed
}

void NeoWindow::circleUpdateEfx(void)
{
  // we assume the update function has determined if it is time to call me
  
//  printData();
//  Serial.println("Updating Circle Effect");
//  Serial.print("   circle_cursor: ");Serial.println(circle_cursor);
   
  // circle moves a single pixel of circle_color around the virtual circle of the window
  // clear the currentPixel
  myStrip->setPixelColor(circle_cursor, 0);
  circle_cursor++;
  if (circle_cursor > myEndPixel) { 
     circle_cursor = myStartPixel;
     efxDone = true; // if we dont check, it just continues
//     Serial.println(" wrapped circle");
  }
  myStrip->setPixelColor(circle_cursor, circle_color);
}

void NeoWindow::setWipeEfx(uint32_t color, uint32_t delayTime) // Wipe color once around window
{
//  printId(); Serial.println("    set to use wipe effect");
  efxDone = false;
  effectDelay = delayTime;  
  curUpdateFunc = &NeoWindow::wipeUpdateEfx;
  
  // starting a Circle Effect using color and time
  wipe_color = color;
  wipe_cursor = myStartPixel;

  myStrip->setPixelColor(wipe_cursor, wipe_color);
  // dont change rest of colors
//  for (int i=circle_cursor+1; i< myEndPixel; i++)
//    myStrip->setPixelColor(i, 0); //set rest of window to black
    
  myStrip->setStripChanged(); // mark the strip changed
}

void NeoWindow::wipeUpdateEfx(void)
{
   // wipe fills the window one pixel each update, then sets Done
  
  myStrip->setPixelColor(wipe_cursor, wipe_color);
  wipe_cursor++;
  
  if (wipe_cursor > myEndPixel) { 
     efxDone = true;
  }
}

void NeoWindow::setBlinkEfx(uint32_t color, uint32_t delayTime, int count)
{
  // set the instance stuff
  efxDone = false;
  effectDelay = delayTime;
  curUpdateFunc = &NeoWindow::blinkUpdateEfx;

  // effect specific stuff
  blink_color = color;
  blink_state = false;
  blink_maxCount = count;
  blink_step = 0;
  
  blinkUpdateEfx();

}

void NeoWindow::blinkUpdateEfx()
{
  if (blink_state)
  {
      fillColor(blink_color);
      blink_state = false;
  } else {
      fillBlack();
      blink_state = true;
      blink_step++;
  }
  
  if (blink_maxCount > 0 && blink_step > blink_maxCount)
    efxDone = true;
}

// couple flags for the state
static const int sparkleFLASH = 1;
static const int sparkleTWEEN = 0;

void NeoWindow::setSparkleEfx(uint32_t color, int flashTime, int tweenTime, int count)
{
  efxDone = false;
  effectDelay = flashTime;
  curUpdateFunc = &NeoWindow::sparkleEfxUpdate;

  sparkleColor = color;
  sparkleFlashTime = flashTime;
  sparkleTweenTime = tweenTime;
  sparkleMaxCount = count;
  sparkleCount = 0;
  sparkleState = sparkleFLASH;
  sparkleCurPixel= random(myStartPixel, myEndPixel);
  fillBlack(); // clear it
  
  // now turn on just that pixel
  myStrip->setPixelColor(sparkleCurPixel,sparkleColor);
  myStrip->setStripChanged(); // mark the strip changed
}

void NeoWindow::sparkleEfxUpdate(void)
{
  if (sparkleState == sparkleFLASH) {
    // it is on, turn off and set to sparkleTWEEN
    myStrip->setPixelColor(sparkleCurPixel, 0);
    sparkleState = sparkleTWEEN;
    effectDelay = sparkleTweenTime;
  } else {
    // it is in TWEEN, so turn to FLASH: select new pixel and turn it on
    sparkleCurPixel= random(myStartPixel, myEndPixel);
    myStrip->setPixelColor(sparkleCurPixel, sparkleColor);
    sparkleState = sparkleFLASH;
    effectDelay = sparkleFlashTime;
  }

  sparkleCount++;
  if (sparkleMaxCount > 0 && sparkleCount > sparkleMaxCount)
  {
    efxDone = true;
  }
}

////////////////////
// Fade = linear fade between two colors, cycle makes if fade back
// fade Phase
static const int fadeFadeIn = 0;
static const int fadeFadeOut = 1;

void NeoWindow::setFadeEfx(uint32_t fromColor, uint32_t toColor, int fadeTime, int type, int count)
{
  efxDone = false;
  effectDelay = fadeTime;
  curUpdateFunc = &NeoWindow::fadeEfxUpdate;

  fadeFromColor = fromColor;
  fadeToColor = toColor;
  fadeType = type;
  fadeMaxCount = count;
  
  // internally we use seperate RGB values
   fadeFromR = myStrip->getRed(fromColor);
   fadeFromG = myStrip->getGreen(fromColor);
   fadeFromB = myStrip->getBlue(fromColor);
  
   fadeToR = myStrip->getRed(toColor);
   fadeToG = myStrip->getGreen(toColor);
   fadeToB = myStrip->getBlue(toColor);

  fadeCurR = fadeFromR;
  fadeCurG = fadeFromG;
  fadeCurB = fadeFromB;

  fadePhase = fadeFadeIn;
  fillColor(fromColor);
  
  myStrip->setStripChanged(); // mark the strip changed
}


void NeoWindow::fadeEfxUpdate(void)
{
  // uses ternary operator to handle incr/decr direction
  if (fadePhase == fadeFadeIn){
    // fade in, fancy way to linearly ramp each of RGB, regardless of whether from>to or from<to
    fadeCurR = ((fadeToR > fadeCurR) ? (fadeCurR+1) : ((fadeToR != fadeCurR) ? fadeCurR-1 : fadeCurR));
    fadeCurG = ((fadeToG > fadeCurG) ? (fadeCurG+1) : ((fadeToG != fadeCurG) ? fadeCurG-1 : fadeCurG));
    fadeCurB = ((fadeToB > fadeCurB) ? (fadeCurB+1) : ((fadeToB != fadeCurB) ? fadeCurB-1 : fadeCurB));

    // faded all the way in? are we cycling?
    if (fadeCurR == fadeToR && fadeCurG == fadeToG && fadeCurB == fadeToB) {
      fadeEfxEndCheck();
      switch (fadeType) {
        case fadeTypeCycle:
          printId(); Serial.println("FadeEfx: cycled all the way in; fade out");
          // faded all in, cycle out
          fadePhase = fadeFadeOut;
          break;
        case fadeTypeJumpBack:
          printId(); Serial.println("FadeEfx: cycled all the way in; not cycle, jump back");
          fadeEfxEndCheck();
          fillColor(fadeFromColor);
          fadeCurR = fadeFromR;
          fadeCurG = fadeFromG;
          fadeCurB = fadeFromB;
        case fadeTypeOnce:
        default:
          //thats all
          break;
      }
    }
  } else { // fade out
    // fade in, fancy way to linearly ramp each of RGB, regardless of whether from>to or from<to
    fadeCurR = ((fadeFromR > fadeCurR) ? (fadeCurR+1) : ((fadeFromR != fadeCurR) ? fadeCurR-1 : fadeCurR));
    fadeCurG = ((fadeFromG > fadeCurG) ? (fadeCurG+1) : ((fadeFromG != fadeCurG) ? fadeCurG-1 : fadeCurG));
    fadeCurB = ((fadeFromB > fadeCurB) ? (fadeCurB+1) : ((fadeFromB != fadeCurB) ? fadeCurB-1 : fadeCurB));

    // faded all the way out?
    if (fadeCurR == fadeFromR && fadeCurG == fadeFromG && fadeCurB == fadeFromB) {
      Serial.println("FadeEfx: cycled all the way out; fade in");
      fadePhase = fadeFadeIn;
      fadeEfxEndCheck();
    }
  }
   fillColor(myStrip->Color(fadeCurR, fadeCurG, fadeCurB));
 
}
void NeoWindow::fadeEfxEndCheck()
{
  fadeCount++;
  if (fadeMaxCount > 0 && fadeCount > fadeMaxCount)
  {
    efxDone = true;
  }
}

